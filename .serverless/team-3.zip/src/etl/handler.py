import boto3
import os
import sys
#import psycopg2-binary
from transform import remove_sensitive_data
from transform import create_items_with_price
import normalise as normalise
import datetime
from dotenv import load_dotenv
import psycopg2.extras
import psycopg2

def load():
    host = os.getenv("DB_HOST")
    port = int(os.getenv("DB_PORT"))
    user = os.getenv("DB_USER")
    db = os.getenv("DB_NAME")
    cluster = os.getenv("DB_CLUSTER")

    # get cluster credentials
    try:
        client = boto3.client('redshift')
        creds = client.get_cluster_credentials(
            DbUser=user,
            DbName=db,
            ClusterIdentifier=cluster,
            DurationSeconds=3600
        )
    except Exception as e:
        print(e)
        sys.exit(1)

    # create object connection to redshift
    try:
        conn = psycopg2.connect(
            dbname=db,
            user=creds["DbUser"],
            password=creds["DbPassword"],
            port=port,
            host=host)
    except Exception as e:
        print(e)
        sys.exit(1)

    transaction = {
        "date": '2021',
        "location": 2,
        "payment_method": "CASH",
        "cost": 20.00}

    with conn.cursor() as cursor:
            psycopg2.extras.execute_values(cursor, """INSERT INTO transactions (date, location, payment_method, cost) VALUES %s;""",
            #cursor.execute( """INSERT INTO transactions (date, location, payment_method, cost) VALUES (%s,%s,%s,%s);""",
                (
                    transaction["date"],
                    transaction["location"],
                    transaction["payment_method"],
                    transaction["cost"]
                )
            )
            conn.commit()

def handle(event, context):
    # # List all files in bucket
    # key = event['Records'][0]['s3']['object']['key']
    # bucket = event['Records'][0]['s3']['bucket']['name']

    # # get_csv_data_from_bucket
    # s3 = boto3.client('s3')
    # s3_object = s3.get_object(Bucket = bucket, Key = key)
    # names = ['date','location', 'customer', 'items', 'cost', 'payment_method', 'card_number']
    # data = pd.read_csv(s3_object['Body'], names=names).to_dict('records')

    # #remove sensitive
    # data = remove_sensitive_data(data)

    # #normalise data
    # not_normal_list, first_item = normalise.seprating_lines(data, "items") # importing func from normalise - why is items in quotation marks?
    # not_normal_list2 = normalise.creating_list_without_item(data)
    # items = normalise.finding_unique_value(first_item) # importing func from normalise
    # items_list = normalise.adding_id(items) # importing func from normalise
    # item_with_price = create_items_with_price(items_list)#creates item table with price and id
    # # normal_list = normalise.creating_list_with_item_id(not_normal_list, items_list) # importing func from normalise
    # pay_list = normalise.extracting_lists(not_normal_list2, "payment_method")
    # location_list = normalise.extracting_lists(not_normal_list2, "location")
    # pay_with_id = normalise.adding_id(pay_list)
    # location_with_id = normalise.adding_id(location_list)
    # normal2_list = normalise.creating_list_with_replacing_id(not_normal_list2, pay_with_id, "payment_method", 1)
    # normal3_list = normalise.creating_list_with_replacing_id(not_normal_list2, location_with_id, "location", 1)

    load()
