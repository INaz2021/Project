def seprating_lines(list_dict, column_key):
    not_normal_list = []
    first_item = []
    for i in list_dict:
        s = i[column_key]
        dictionary = {}
        item = s.split(',')
        number = len(item) / 3
        avg = len(item) / number
        out = []
        last = 0.0
        while last < len(item):
            out.append(item[int(last):int(last + avg)])
            last += avg    
        for k in out:
            s = [k[i:i + 1] for i in range(0, len(k), 1)]
            first_item.append(s)
            dictionary["date"] = i["date"]
            dictionary["location"] = i["location"]
            dictionary["items"] = s
            dictionary["payment_method"] = i["payment_method"]
            dictionary["cost"] = i["cost"]
            not_normal_list.append(dictionary)
            dictionary = {}
    return not_normal_list, first_item

def finding_unique_value(list_list):
    items = []
    for w in list_list:
        if w not in items:
            items.append(w)
    return items

def adding_id(entry_list):
    id_items = []        
    for i in range(len(entry_list)):
        id_items.append(i+1)    
    for x, y in zip(entry_list, id_items):
        x.append(y)
    return entry_list

def creating_list_with_item_id(not_normal_list, items_list):
    for key in not_normal_list:
        for i in items_list:
            list_difference = []
            for j in key["items"]:
                if j not in i:
                    list_difference.append(j)
            if len(list_difference) <= 1:
                print(j)
                key["items"] = i[3]
                break
    return not_normal_list

def creating_list_without_item(file):
    file_copy = []
    for i in file:
        dictionary = i.copy()
        file_copy.append(dictionary)
    new_list = [{k: v for k, v in d.items() if k != 'items'} for d in file_copy]
    return new_list

def extracting_lists(list_name, key_name):
    pay = []
    for i in list_name:
        item = i[key_name].split(',')
        pay.append(item)
    unique = finding_unique_value(pay)
    return unique

def creating_list_with_replacing_id(not_normal_list, items_list, key_name, id):
    for key in not_normal_list:
        for i in items_list:
            if key[key_name] == i[0]:
                key[key_name] = i[id]
    return not_normal_list
